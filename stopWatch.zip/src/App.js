import "./App.css";
import Stopwatch from "./components/stopWatch";

function App() {
  return (
    <div className="App">
      <Stopwatch />
    </div>
  );
}

export default App;

